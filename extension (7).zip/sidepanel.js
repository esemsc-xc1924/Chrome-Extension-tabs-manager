const LIST_ELEMENT = document.querySelector('ul');

function updateUI(){

  // Reset element.
  LIST_ELEMENT.innerHTML = '';

  chrome.tabs
    .query({
      currentWindow: true
    })
    .then((tabs) => {
      for (const tab of tabs) {
        const element = document.createElement('li');
        element.innerText = tab.title;

        element.addEventListener('click', async () => {
          // need to focus window as well as the active tab
          await chrome.tabs.update(tab.id, { active: true });
          await chrome.windows.update(tab.windowId, { focused: true });
        });

        LIST_ELEMENT.append(element);
      }
    });
}

updateUI();

chrome.tabs.onCreated.addListener(updateUI);
chrome.tabs.onRemoved.addListener(updateUI);
chrome.tabs.onMoved.addListener(updateUI);

