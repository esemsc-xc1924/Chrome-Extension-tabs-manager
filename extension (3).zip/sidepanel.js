const LIST_ELEMENT = document.querySelector('ul');

chrome.tabs
  .query({
    currentWindow: true
  })
  .then((tabs) => {
    for (const tab of tabs) {
      const element = document.createElement('li');
      element.innerText = tab.title;
      LIST_ELEMENT.append(element);
    }
  });