document.getElementById("yellow").addEventListener("click", () => {
  changeBackgroundColor("yellow");
});

document.getElementById("blue").addEventListener("click", () => {
  changeBackgroundColor("blue");
});

document.getElementById("green").addEventListener("click", () => {
  changeBackgroundColor("green");
});

function changeBackgroundColor(color) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (color) => {
        document.body.style.backgroundColor = color;
      },
      args: [color],
    });
  });
}